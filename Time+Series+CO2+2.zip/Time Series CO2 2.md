

```python
%matplotlib inline
import numpy as np
import pandas as pd
import matplotlib.pylab
import matplotlib.pyplot as plt
from matplotlib.pylab import rcParams
rcParams['figure.figsize'] = 20, 16
```


```python
import warnings
import itertools
warnings.filterwarnings("ignore") # specify to ignore warning messages
```


```python
df = pd.read_csv("MER_T12_06.csv")
df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSN</th>
      <th>YYYYMM</th>
      <th>Value</th>
      <th>Column_Order</th>
      <th>Description</th>
      <th>Unit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>CLEIEUS</td>
      <td>197301</td>
      <td>72.076</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CLEIEUS</td>
      <td>197302</td>
      <td>64.442</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CLEIEUS</td>
      <td>197303</td>
      <td>64.084</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CLEIEUS</td>
      <td>197304</td>
      <td>60.842</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>4</th>
      <td>CLEIEUS</td>
      <td>197305</td>
      <td>61.798</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
  </tbody>
</table>
</div>




```python
dateparse = lambda x: pd.to_datetime(x, format='%Y%m', errors = 'coerce')
df = pd.read_csv("MER_T12_06.csv", parse_dates=['YYYYMM'], index_col='YYYYMM', date_parser=dateparse) 
df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSN</th>
      <th>Value</th>
      <th>Column_Order</th>
      <th>Description</th>
      <th>Unit</th>
    </tr>
    <tr>
      <th>YYYYMM</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1973-01-01</th>
      <td>CLEIEUS</td>
      <td>72.076</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-02-01</th>
      <td>CLEIEUS</td>
      <td>64.442</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-03-01</th>
      <td>CLEIEUS</td>
      <td>64.084</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-04-01</th>
      <td>CLEIEUS</td>
      <td>60.842</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-05-01</th>
      <td>CLEIEUS</td>
      <td>61.798</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
  </tbody>
</table>
</div>




```python
ts = df[pd.Series(pd.to_datetime(df.index, errors='coerce')).notnull().values]
ts.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSN</th>
      <th>Value</th>
      <th>Column_Order</th>
      <th>Description</th>
      <th>Unit</th>
    </tr>
    <tr>
      <th>YYYYMM</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1973-01-01</th>
      <td>CLEIEUS</td>
      <td>72.076</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-02-01</th>
      <td>CLEIEUS</td>
      <td>64.442</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-03-01</th>
      <td>CLEIEUS</td>
      <td>64.084</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-04-01</th>
      <td>CLEIEUS</td>
      <td>60.842</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-05-01</th>
      <td>CLEIEUS</td>
      <td>61.798</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
  </tbody>
</table>
</div>




```python
ts.dtypes
```




    MSN             object
    Value           object
    Column_Order     int64
    Description     object
    Unit            object
    dtype: object




```python
#ss = ts.copy(deep=True)
ts['Value'] = pd.to_numeric(ts['Value'] , errors='coerce')
ts.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSN</th>
      <th>Value</th>
      <th>Column_Order</th>
      <th>Description</th>
      <th>Unit</th>
    </tr>
    <tr>
      <th>YYYYMM</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1973-01-01</th>
      <td>CLEIEUS</td>
      <td>72.076</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-02-01</th>
      <td>CLEIEUS</td>
      <td>64.442</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-03-01</th>
      <td>CLEIEUS</td>
      <td>64.084</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-04-01</th>
      <td>CLEIEUS</td>
      <td>60.842</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
    <tr>
      <th>1973-05-01</th>
      <td>CLEIEUS</td>
      <td>61.798</td>
      <td>1</td>
      <td>Coal Electric Power Sector CO2 Emissions</td>
      <td>Million Metric Tons of Carbon Dioxide</td>
    </tr>
  </tbody>
</table>
</div>




```python
ts.dtypes
```




    MSN              object
    Value           float64
    Column_Order      int64
    Description      object
    Unit             object
    dtype: object




```python
ts.info()
```

    <class 'pandas.core.frame.DataFrame'>
    DatetimeIndex: 4932 entries, 1973-01-01 to 2018-08-01
    Data columns (total 5 columns):
    MSN             4932 non-null object
    Value           4548 non-null float64
    Column_Order    4932 non-null int64
    Description     4932 non-null object
    Unit            4932 non-null object
    dtypes: float64(1), int64(1), object(3)
    memory usage: 231.2+ KB
    


```python
ts.dropna(inplace = True)
```


```python
ts.info()
```

    <class 'pandas.core.frame.DataFrame'>
    DatetimeIndex: 4548 entries, 1973-01-01 to 2018-08-01
    Data columns (total 5 columns):
    MSN             4548 non-null object
    Value           4548 non-null float64
    Column_Order    4548 non-null int64
    Description     4548 non-null object
    Unit            4548 non-null object
    dtypes: float64(1), int64(1), object(3)
    memory usage: 213.2+ KB
    


```python
Energy_sources = ts.groupby('Description')
```


```python
Emissions = ts.iloc[:,1:]   # Monthly total emissions (mte)
Emissions= Emissions.groupby(['Description', pd.TimeGrouper('M')])['Value'].sum().unstack(level = 0)
mte = Emissions['Coal Electric Power Sector CO2 Emissions'] # monthly total emissions (mte)
mte.head()
```




    YYYYMM
    1973-01-31    72.076
    1973-02-28    64.442
    1973-03-31    64.084
    1973-04-30    60.842
    1973-05-31    61.798
    Name: Coal Electric Power Sector CO2 Emissions, dtype: float64




```python
mte.tail()
```




    YYYYMM
    2018-04-30     73.611
    2018-05-31     86.092
    2018-06-30    101.692
    2018-07-31    115.765
    2018-08-31    115.582
    Name: Coal Electric Power Sector CO2 Emissions, dtype: float64




```python
import statsmodels
import statsmodels.api as sm
from statsmodels.tsa.stattools import coint, adfuller
```


```python
plt.plot(mte)
```




    [<matplotlib.lines.Line2D at 0x1f8dc62db70>]




![png](output_15_1.png)



```python
def TestStationaryPlot(ts):
    rol_mean = ts.rolling(window = 12, center = False).mean()
    rol_std = ts.rolling(window = 12, center = False).std()
    
    plt.plot(ts, color = 'blue',label = 'Original Data')
    plt.plot(rol_mean, color = 'red', label = 'Rolling Mean')
    plt.plot(rol_std, color ='black', label = 'Rolling Std')
    plt.xticks(fontsize = 25)
    plt.yticks(fontsize = 25)
    
    plt.xlabel('Time in Years', fontsize = 25)
    plt.ylabel('Total Emissions', fontsize = 25)
    plt.legend(loc='best', fontsize = 25)
    plt.title('Rolling Mean & Standard Deviation', fontsize = 25)
    plt.show(block= True)
```


```python
def TestStationaryAdfuller(ts, cutoff = 0.01):
    ts_test = adfuller(ts, autolag = 'AIC')
    ts_test_output = pd.Series(ts_test[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    
    for key,value in ts_test[4].items():
        ts_test_output['Critical Value (%s)'%key] = value
    print(ts_test_output)
    
    if ts_test[1] <= cutoff:
        print("Strong evidence against the null hypothesis, reject the null hypothesis. Data has no unit root, hence it is stationary")
    else:
        print("Weak evidence against null hypothesis, time series has a unit root, indicating it is non-stationary ")
```


```python
TestStationaryPlot(mte)
```


![png](output_18_0.png)



```python
TestStationaryAdfuller(mte)
```

    Test Statistic                  -1.753511
    p-value                          0.403774
    #Lags Used                      14.000000
    Number of Observations Used    533.000000
    Critical Value (10%)            -2.569666
    Critical Value (1%)             -3.442678
    Critical Value (5%)             -2.866978
    dtype: float64
    Weak evidence against null hypothesis, time series has a unit root, indicating it is non-stationary 
    


```python
ts_log = np.log(mte)
plt.plot(ts_log)
```




    [<matplotlib.lines.Line2D at 0x1f8dc6d6898>]




![png](output_20_1.png)



```python
moving_avg = pd.rolling_mean(ts_log,12)
plt.plot(ts_log)
plt.plot(moving_avg, color='red')
```




    [<matplotlib.lines.Line2D at 0x1f8dcb71d30>]




![png](output_21_1.png)



```python
ts_log_moving_avg_diff = ts_log - moving_avg
ts_log_moving_avg_diff.head(12)
```




    YYYYMM
    1973-01-31         NaN
    1973-02-28         NaN
    1973-03-31         NaN
    1973-04-30         NaN
    1973-05-31         NaN
    1973-06-30         NaN
    1973-07-31         NaN
    1973-08-31         NaN
    1973-09-30         NaN
    1973-10-31         NaN
    1973-11-30         NaN
    1973-12-31    0.051997
    Name: Coal Electric Power Sector CO2 Emissions, dtype: float64




```python
ts_log_moving_avg_diff.dropna(inplace=True)
TestStationaryPlot(ts_log_moving_avg_diff)
```


![png](output_23_0.png)



```python
TestStationaryAdfuller(ts_log_moving_avg_diff)
```

    Test Statistic                -6.043702e+00
    p-value                        1.327258e-07
    #Lags Used                     1.400000e+01
    Number of Observations Used    5.220000e+02
    Critical Value (10%)          -2.569727e+00
    Critical Value (1%)           -3.442940e+00
    Critical Value (5%)           -2.867093e+00
    dtype: float64
    Strong evidence against the null hypothesis, reject the null hypothesis. Data has no unit root, hence it is stationary
    


```python
expwighted_avg = pd.ewma(ts_log, halflife=12)
plt.plot(ts_log)
plt.plot(expwighted_avg, color='red')
```




    [<matplotlib.lines.Line2D at 0x1f8dc691d30>]




![png](output_25_1.png)



```python
ts_log_ewma_diff = ts_log - expwighted_avg
TestStationaryPlot(ts_log_ewma_diff)
```


![png](output_26_0.png)



```python
TestStationaryAdfuller(ts_log_ewma_diff)
```

    Test Statistic                  -2.510361
    p-value                          0.112974
    #Lags Used                      16.000000
    Number of Observations Used    531.000000
    Critical Value (10%)            -2.569677
    Critical Value (1%)             -3.442725
    Critical Value (5%)             -2.866998
    dtype: float64
    Weak evidence against null hypothesis, time series has a unit root, indicating it is non-stationary 
    


```python
ts_log_diff = ts_log - ts_log.shift()
plt.plot(ts_log_diff)
```




    [<matplotlib.lines.Line2D at 0x1f8dcbf7eb8>]




![png](output_28_1.png)



```python
ts_log_diff.dropna(inplace=True)
TestStationaryPlot(ts_log_diff)
```


![png](output_29_0.png)



```python
TestStationaryAdfuller(ts_log_diff)
```

    Test Statistic                -5.726795e+00
    p-value                        6.742131e-07
    #Lags Used                     1.300000e+01
    Number of Observations Used    5.330000e+02
    Critical Value (10%)          -2.569666e+00
    Critical Value (1%)           -3.442678e+00
    Critical Value (5%)           -2.866978e+00
    dtype: float64
    Strong evidence against the null hypothesis, reject the null hypothesis. Data has no unit root, hence it is stationary
    


```python
from statsmodels.tsa.seasonal import seasonal_decompose
decomposition = seasonal_decompose(ts_log)

trend = decomposition.trend
seasonal = decomposition.seasonal
residual = decomposition.resid

plt.subplot(411)
plt.plot(ts_log, label='Original')
plt.legend(loc='best')
plt.subplot(412)
plt.plot(trend, label='Trend')
plt.legend(loc='best')
plt.subplot(413)
plt.plot(seasonal,label='Seasonality')
plt.legend(loc='best')
plt.subplot(414)
plt.plot(residual, label='Residuals')
plt.legend(loc='best')
plt.tight_layout()
```


![png](output_31_0.png)



```python
ts_log_decompose = residual
ts_log_decompose.dropna(inplace=True)
TestStationaryPlot(ts_log_decompose)
```


![png](output_32_0.png)



```python
TestStationaryAdfuller(ts_log_decompose)
```

    Test Statistic                -1.062696e+01
    p-value                        5.334452e-19
    #Lags Used                     1.400000e+01
    Number of Observations Used    5.210000e+02
    Critical Value (10%)          -2.569733e+00
    Critical Value (1%)           -3.442964e+00
    Critical Value (5%)           -2.867103e+00
    dtype: float64
    Strong evidence against the null hypothesis, reject the null hypothesis. Data has no unit root, hence it is stationary
    


```python
from statsmodels.tsa.stattools import acf, pacf
```


```python
lag_acf = acf(ts_log_diff, nlags=20)
lag_pacf = pacf(ts_log_diff, nlags=20, method='ols')
```


```python
#Plot ACF: 
plt.subplot(121) 
plt.plot(lag_acf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.title('Autocorrelation Function')
```




    Text(0.5,1,'Autocorrelation Function')




![png](output_36_1.png)



```python
#Plot PACF:
plt.subplot(122)
plt.plot(lag_pacf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.title('Partial Autocorrelation Function')
plt.tight_layout()
```


![png](output_37_0.png)



```python
from statsmodels.tsa.stattools import ARMA
def best_AR_MA_checker(df,lower,upper):
    from statsmodels.tsa.stattools import ARMA
    from statsmodels.tsa.stattools import adfuller
    arg=np.arange(lower,upper)
    arg1=np.arange(lower,upper)
    best_param_i=0
    best_param_j=0
    temp=12000000
    rs=99
    for i in arg:
        for j in arg1:
            model=ARMA(df, order=(i,0,j))
            result=model.fit(disp=0)
            resid=adfuller(result.resid)
            if (result.aic<temp and  adfuller(result.resid)[1]<0.05):
                temp=result.aic
                best_param_i=i
                best_param_j=j
                rs=resid[1]
                
                
            print ("AR: %d, MA: %d, AIC: %d; resid stationarity check: %d"%(i,j,result.aic,resid[1]))
            
    print("the following function prints AIC criteria and finds the paramters for minimum AIC criteria")        
    print("best AR: %d, best MA: %d, best AIC: %d;  resid stationarity check:%d"%(best_param_i, best_param_j, temp, rs))     
best_AR_MA_checker(ts_log_decompose,1,6) #For each parameter I want to try from 0 to 2
```

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 1, MA: 1, AIC: -2039; resid stationarity check: 0
    AR: 1, MA: 2, AIC: -2039; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 1, MA: 3, AIC: -2039; resid stationarity check: 0
    AR: 1, MA: 4, AIC: -2039; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 1, MA: 5, AIC: -2039; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 2, MA: 1, AIC: -2083; resid stationarity check: 0
    AR: 2, MA: 2, AIC: -2083; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 2, MA: 3, AIC: -2083; resid stationarity check: 0
    AR: 2, MA: 4, AIC: -2083; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 2, MA: 5, AIC: -2083; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 3, MA: 1, AIC: -2090; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 3, MA: 2, AIC: -2090; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 3, MA: 3, AIC: -2090; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 3, MA: 4, AIC: -2090; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 3, MA: 5, AIC: -2090; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 4, MA: 1, AIC: -2098; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 4, MA: 2, AIC: -2098; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 4, MA: 3, AIC: -2098; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 4, MA: 4, AIC: -2098; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 4, MA: 5, AIC: -2098; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 5, MA: 1, AIC: -2103; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 5, MA: 2, AIC: -2103; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 5, MA: 3, AIC: -2103; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 5, MA: 4, AIC: -2103; resid stationarity check: 0
    

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

    AR: 5, MA: 5, AIC: -2103; resid stationarity check: 0
    the following function prints AIC criteria and finds the paramters for minimum AIC criteria
    best AR: 5, best MA: 1, best AIC: -2103;  resid stationarity check:0
    


```python
from statsmodels.tsa.stattools import ARMA
model = ARMA(ts_log_decompose, order=(2,1))
results = model.fit(trend='nc', method='css-mle')
print(results.summary())
RSS = np.sum((results.resid)**2)
print(RSS)
```

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

                                             ARMA Model Results                                         
    ====================================================================================================
    Dep. Variable:     Coal Electric Power Sector CO2 Emissions   No. Observations:                  536
    Model:                                           ARMA(2, 1)   Log Likelihood                1100.308
    Method:                                             css-mle   S.D. of innovations              0.031
    Date:                                      Sun, 02 Dec 2018   AIC                          -2192.616
    Time:                                              20:30:34   BIC                          -2175.480
    Sample:                                          07-31-1973   HQIC                         -2185.912
                                                   - 02-28-2018                                         
    ==================================================================================================================
                                                         coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------------------------------------------
    ar.L1.Coal Electric Power Sector CO2 Emissions     1.2753      0.035     35.951      0.000       1.206       1.345
    ar.L2.Coal Electric Power Sector CO2 Emissions    -0.5801      0.036    -16.276      0.000      -0.650      -0.510
    ma.L1.Coal Electric Power Sector CO2 Emissions    -0.9867      0.006   -167.570      0.000      -0.998      -0.975
                                        Roots                                    
    =============================================================================
                      Real          Imaginary           Modulus         Frequency
    -----------------------------------------------------------------------------
    AR.1            1.0993           -0.7180j            1.3130           -0.0921
    AR.2            1.0993           +0.7180j            1.3130            0.0921
    MA.1            1.0135           +0.0000j            1.0135            0.0000
    -----------------------------------------------------------------------------
    0.5169906750089697
    


```python
model = ARMA(ts_log_decompose, order=(4,3))
results = model.fit(trend='nc', method='css-mle')
print(results.summary())
RSS = np.sum((results.resid)**2)
print(RSS)
```

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

                                             ARMA Model Results                                         
    ====================================================================================================
    Dep. Variable:     Coal Electric Power Sector CO2 Emissions   No. Observations:                  536
    Model:                                           ARMA(4, 3)   Log Likelihood                1109.451
    Method:                                             css-mle   S.D. of innovations              0.030
    Date:                                      Sun, 02 Dec 2018   AIC                          -2202.903
    Time:                                              20:30:36   BIC                          -2168.630
    Sample:                                          07-31-1973   HQIC                         -2189.494
                                                   - 02-28-2018                                         
    ==================================================================================================================
                                                         coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------------------------------------------
    ar.L1.Coal Electric Power Sector CO2 Emissions     1.1845      0.038     31.257      0.000       1.110       1.259
    ar.L2.Coal Electric Power Sector CO2 Emissions    -1.4369      0.035    -40.696      0.000      -1.506      -1.368
    ar.L3.Coal Electric Power Sector CO2 Emissions     1.2224      0.033     36.975      0.000       1.158       1.287
    ar.L4.Coal Electric Power Sector CO2 Emissions    -0.6041      0.035    -17.176      0.000      -0.673      -0.535
    ma.L1.Coal Electric Power Sector CO2 Emissions    -0.8915      0.022    -40.709      0.000      -0.934      -0.849
    ma.L2.Coal Electric Power Sector CO2 Emissions     0.8742      0.021     40.857      0.000       0.832       0.916
    ma.L3.Coal Electric Power Sector CO2 Emissions    -0.9543      0.020    -46.825      0.000      -0.994      -0.914
                                        Roots                                    
    =============================================================================
                      Real          Imaginary           Modulus         Frequency
    -----------------------------------------------------------------------------
    AR.1           -0.0631           -1.0023j            1.0043           -0.2600
    AR.2           -0.0631           +1.0023j            1.0043            0.2600
    AR.3            1.0749           -0.6972j            1.2812           -0.0916
    AR.4            1.0749           +0.6972j            1.2812            0.0916
    MA.1            1.0140           -0.0000j            1.0140           -0.0000
    MA.2           -0.0489           -1.0154j            1.0166           -0.2577
    MA.3           -0.0489           +1.0154j            1.0166            0.2577
    -----------------------------------------------------------------------------
    0.49942053019362925
    


```python
model = ARMA(ts_log_decompose, order=(5,4))
results = model.fit(trend='nc', method='css-mle')
print(results.summary())
RSS = np.sum((results.resid)**2)
print(RSS)
```

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

                                             ARMA Model Results                                         
    ====================================================================================================
    Dep. Variable:     Coal Electric Power Sector CO2 Emissions   No. Observations:                  536
    Model:                                           ARMA(5, 4)   Log Likelihood                1130.915
    Method:                                             css-mle   S.D. of innovations              0.029
    Date:                                      Sun, 02 Dec 2018   AIC                          -2241.830
    Time:                                              20:30:43   BIC                          -2198.989
    Sample:                                          07-31-1973   HQIC                         -2225.070
                                                   - 02-28-2018                                         
    ==================================================================================================================
                                                         coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------------------------------------------
    ar.L1.Coal Electric Power Sector CO2 Emissions     2.6857      0.148     18.095      0.000       2.395       2.977
    ar.L2.Coal Electric Power Sector CO2 Emissions    -3.6410      0.362    -10.049      0.000      -4.351      -2.931
    ar.L3.Coal Electric Power Sector CO2 Emissions     2.7327      0.462      5.909      0.000       1.826       3.639
    ar.L4.Coal Electric Power Sector CO2 Emissions    -1.0588      0.314     -3.374      0.001      -1.674      -0.444
    ar.L5.Coal Electric Power Sector CO2 Emissions     0.0994      0.104      0.960      0.338      -0.104       0.303
    ma.L1.Coal Electric Power Sector CO2 Emissions    -2.4574      0.140    -17.593      0.000      -2.731      -2.184
    ma.L2.Coal Electric Power Sector CO2 Emissions     2.8307      0.289      9.799      0.000       2.265       3.397
    ma.L3.Coal Electric Power Sector CO2 Emissions    -1.7763      0.281     -6.323      0.000      -2.327      -1.226
    ma.L4.Coal Electric Power Sector CO2 Emissions     0.4114      0.130      3.174      0.002       0.157       0.665
                                        Roots                                    
    =============================================================================
                      Real          Imaginary           Modulus         Frequency
    -----------------------------------------------------------------------------
    AR.1            0.5071           -0.8719j            1.0086           -0.1662
    AR.2            0.5071           +0.8719j            1.0086            0.1662
    AR.3            1.0116           -0.5251j            1.1398           -0.0762
    AR.4            1.0116           +0.5251j            1.1398            0.0762
    AR.5            7.6089           -0.0000j            7.6089           -0.0000
    MA.1            0.5553           -0.8847j            1.0446           -0.1608
    MA.2            0.5553           +0.8847j            1.0446            0.1608
    MA.3            1.0176           -0.0000j            1.0176           -0.0000
    MA.4            2.1891           -0.0000j            2.1891           -0.0000
    -----------------------------------------------------------------------------
    0.46055555693800965
    


```python
model = ARMA(ts_log_decompose, order=(6,5))
results = model.fit(trend='nc', method='css-mle')
print(results.summary())
RSS = np.sum((results.resid)**2)
print(RSS)
```

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    

                                             ARMA Model Results                                         
    ====================================================================================================
    Dep. Variable:     Coal Electric Power Sector CO2 Emissions   No. Observations:                  536
    Model:                                           ARMA(6, 5)   Log Likelihood                1141.493
    Method:                                             css-mle   S.D. of innovations              0.029
    Date:                                      Sun, 02 Dec 2018   AIC                          -2258.986
    Time:                                              20:30:54   BIC                          -2207.577
    Sample:                                          07-31-1973   HQIC                         -2238.874
                                                   - 02-28-2018                                         
    ==================================================================================================================
                                                         coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------------------------------------------
    ar.L1.Coal Electric Power Sector CO2 Emissions     2.5111      0.135     18.638      0.000       2.247       2.775
    ar.L2.Coal Electric Power Sector CO2 Emissions    -3.8817      0.296    -13.103      0.000      -4.462      -3.301
    ar.L3.Coal Electric Power Sector CO2 Emissions     3.8585      0.378     10.197      0.000       3.117       4.600
    ar.L4.Coal Electric Power Sector CO2 Emissions    -2.8479      0.324     -8.791      0.000      -3.483      -2.213
    ar.L5.Coal Electric Power Sector CO2 Emissions     1.4592      0.200      7.314      0.000       1.068       1.850
    ar.L6.Coal Electric Power Sector CO2 Emissions    -0.4942      0.073     -6.789      0.000      -0.637      -0.352
    ma.L1.Coal Electric Power Sector CO2 Emissions    -2.2737      0.150    -15.163      0.000      -2.568      -1.980
    ma.L2.Coal Electric Power Sector CO2 Emissions     3.0358      0.301     10.092      0.000       2.446       3.625
    ma.L3.Coal Electric Power Sector CO2 Emissions    -2.6214      0.324     -8.087      0.000      -3.257      -1.986
    ma.L4.Coal Electric Power Sector CO2 Emissions     1.4079      0.223      6.301      0.000       0.970       1.846
    ma.L5.Coal Electric Power Sector CO2 Emissions    -0.5299      0.094     -5.632      0.000      -0.714      -0.346
                                        Roots                                    
    =============================================================================
                      Real          Imaginary           Modulus         Frequency
    -----------------------------------------------------------------------------
    AR.1           -0.0113           -1.2428j            1.2429           -0.2514
    AR.2           -0.0113           +1.2428j            1.2429            0.2514
    AR.3            0.9832           -0.5517j            1.1274           -0.0814
    AR.4            0.9832           +0.5517j            1.1274            0.0814
    AR.5            0.5043           -0.8810j            1.0151           -0.1673
    AR.6            0.5043           +0.8810j            1.0151            0.1673
    MA.1            1.0167           -0.0000j            1.0167           -0.0000
    MA.2            0.5989           -0.9117j            1.0908           -0.1575
    MA.3            0.5989           +0.9117j            1.0908            0.1575
    MA.4            0.2210           -1.2292j            1.2489           -0.2217
    MA.5            0.2210           +1.2292j            1.2489            0.2217
    -----------------------------------------------------------------------------
    0.4428111422937262
    


```python
model = ARMA(ts_log_decompose, order=(8,6))
results = model.fit(trend='nc', method='css-mle')
print(results.summary())
RSS = np.sum((results.resid)**2)
print(RSS)
```

    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\tsa\base\tsa_model.py:171: ValueWarning: No frequency information was provided, so inferred frequency M will be used.
      % freq, ValueWarning)
    C:\Users\Cassandra Rosa\Anaconda3\lib\site-packages\statsmodels\base\model.py:488: HessianInversionWarning: Inverting hessian failed, no bse or cov_params available
      'available', HessianInversionWarning)
    

                                             ARMA Model Results                                         
    ====================================================================================================
    Dep. Variable:     Coal Electric Power Sector CO2 Emissions   No. Observations:                  536
    Model:                                           ARMA(8, 6)   Log Likelihood                1145.877
    Method:                                             css-mle   S.D. of innovations              0.028
    Date:                                      Sun, 02 Dec 2018   AIC                          -2261.754
    Time:                                              20:31:08   BIC                          -2197.492
    Sample:                                          07-31-1973   HQIC                         -2236.613
                                                   - 02-28-2018                                         
    ==================================================================================================================
                                                         coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------------------------------------------
    ar.L1.Coal Electric Power Sector CO2 Emissions     1.1847      0.063     18.904      0.000       1.062       1.308
    ar.L2.Coal Electric Power Sector CO2 Emissions    -1.2400      0.083    -14.858      0.000      -1.404      -1.076
    ar.L3.Coal Electric Power Sector CO2 Emissions     0.1031      0.085      1.218      0.224      -0.063       0.269
    ar.L4.Coal Electric Power Sector CO2 Emissions     0.6833      0.052     13.022      0.000       0.580       0.786
    ar.L5.Coal Electric Power Sector CO2 Emissions    -1.3317      0.057    -23.270      0.000      -1.444      -1.220
    ar.L6.Coal Electric Power Sector CO2 Emissions     0.9896      0.086     11.563      0.000       0.822       1.157
    ar.L7.Coal Electric Power Sector CO2 Emissions    -0.3996      0.074     -5.390      0.000      -0.545      -0.254
    ar.L8.Coal Electric Power Sector CO2 Emissions    -0.1696      0.050     -3.416      0.001      -0.267      -0.072
    ma.L1.Coal Electric Power Sector CO2 Emissions    -0.9323      0.051    -18.313      0.000      -1.032      -0.833
    ma.L2.Coal Electric Power Sector CO2 Emissions     0.7486      0.054     13.825      0.000       0.643       0.855
    ma.L3.Coal Electric Power Sector CO2 Emissions     0.0741      0.054      1.363      0.173      -0.032       0.181
    ma.L4.Coal Electric Power Sector CO2 Emissions    -0.9059      0.047    -19.185      0.000      -0.998      -0.813
    ma.L5.Coal Electric Power Sector CO2 Emissions     0.8865      0.052     16.962      0.000       0.784       0.989
    ma.L6.Coal Electric Power Sector CO2 Emissions    -0.8145      0.055    -14.899      0.000      -0.922      -0.707
                                        Roots                                    
    =============================================================================
                      Real          Imaginary           Modulus         Frequency
    -----------------------------------------------------------------------------
    AR.1            1.0001           -0.5510j            1.1419           -0.0801
    AR.2            1.0001           +0.5510j            1.1419            0.0801
    AR.3            0.5077           -0.8759j            1.0124           -0.1664
    AR.4            0.5077           +0.8759j            1.0124            0.1664
    AR.5           -0.0636           -1.0093j            1.0113           -0.2600
    AR.6           -0.0636           +1.0093j            1.0113            0.2600
    AR.7           -1.0216           -0.0000j            1.0216           -0.5000
    AR.8           -4.2231           -0.0000j            4.2231           -0.5000
    MA.1           -1.0000           -0.0000j            1.0000           -0.5000
    MA.2            1.0165           -0.0000j            1.0165           -0.0000
    MA.3           -0.0382           -1.0350j            1.0357           -0.2559
    MA.4           -0.0382           +1.0350j            1.0357            0.2559
    MA.5            0.5741           -0.8924j            1.0611           -0.1590
    MA.6            0.5741           +0.8924j            1.0611            0.1590
    -----------------------------------------------------------------------------
    0.43518129246212606
    


```python

```


```python

```
